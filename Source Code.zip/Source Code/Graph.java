import java.util.*;
/**
 * This class represents the network of dynos and bonds as a undirected graph(the bonds were biderectional). 
 * So making an analogy dynos are represented by nodes of the graph and potential bonds as its edges.
 * We chose to reprsent the graph using an adjecancy list because the restriction on bonds(edges) ensures the graph is sparse.
 */
public class Graph {
    int n; // Number of nodes.
    List<List<Integer>> adj; 
/**
 *This is a call to the constructor, which initializes the adjecancy list for n dynos(nodes).
 * @param n the number of dynos in the system 
 */
    public Graph(int n) {
        this.n = n;
        adj = new ArrayList<>();
        for (int i = 0; i <= n; i++) {
            adj.add(new ArrayList<>());
        }
    }
/**
 * Adds a bidirectional(undirected) bond between dynos u and v.
 * @param u the first dyno
 * @param v the second dyno
 */
    public void addEdge(int u, int v) {
        adj.get(u).add(v);
        adj.get(v).add(u);
    }
/**
 * Returns the neighbors of dyno u.
 * @param u the dyno whose neighbors are to be returned
 * @return list of neighboring dynos of u
*/
    public List<Integer> neighbors(int u) {
        return adj.get(u);
    }
}
