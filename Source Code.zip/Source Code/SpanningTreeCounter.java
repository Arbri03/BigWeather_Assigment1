import java.util.*;
/**
 * This class uses Kirchhoff’s Matrix-Tree Theorem to count the number of spanning trees
 * in a given component, enabling configuration counting for minimal cost solutions.
 */
public class SpanningTreeCounter {
/**
 * Counts the number of spanning trees in a connected component using the determinant
 * of the Laplacian matrix's minor (Kirchhoff’s Theorem).
 * @param component the list of dynos in the connected component
 * @param graph the full graph
 * @return the number of spanning trees in the component
*/
    public static long countSpanningTrees(List<Integer> component, Graph graph) {
        int n = component.size();
        long[][] laplacian = buildLaplacian(component, graph);

        // Remove first row and column
        long[][] reduced = new long[n - 1][n - 1];
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < n; j++) {
                reduced[i - 1][j - 1] = laplacian[i][j];
            }
        }
		
        return Math.round(determinant(reduced));
    }
/**
 * Builds the Laplacian matrix of a component.
 * Laplacian[i][i] = degree of node i
 * Laplacian[i][j] = -1 if i and j are connected
 * @param component list of dyno IDs in the component
 * @param graph the graph containing all dynos and edges
 * @return the Laplacian matrix
*/
    private static long[][] buildLaplacian(List<Integer> component, Graph graph) {
        int n = component.size();
        long[][] L = new long[n][n];

        Map<Integer, Integer> index = new HashMap<>();
        for (int i = 0; i < n; i++) index.put(component.get(i), i);

        for (int i = 0; i < n; i++) {
            int u = component.get(i);
            for (int v : graph.neighbors(u)) {
                if (index.containsKey(v)) {
                    int j = index.get(v);
                    L[i][j] -= 1;
                    L[i][i] += 1;
                }
            }
        }
        return L;
    }
/**
 * Computes the determinant of a matrix using Gaussian elimination with pivoting.
 * @param matrix the matrix whose determinant is needed
 * @return the determinant, rounded to the nearest integer
*/
    private static double determinant(long[][] matrix) {
        int n = matrix.length;
        double[][] mat = new double[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                mat[i][j] = matrix[i][j];

        double det = 1;
        for (int i = 0; i < n; i++) {
            int pivot = i;
            for (int j = i + 1; j < n; j++)
                if (Math.abs(mat[j][i]) > Math.abs(mat[pivot][i]))
                    pivot = j;

            if (Math.abs(mat[pivot][i]) < 1e-9) return 0;
            if (i != pivot) {
                double[] temp = mat[i];
                mat[i] = mat[pivot];
                mat[pivot] = temp;
                det *= -1;
            }

            det *= mat[i][i];
            for (int j = i + 1; j < n; j++) {
                double factor = mat[j][i] / mat[i][i];
                for (int k = i; k < n; k++) {
                    mat[j][k] -= factor * mat[i][k];
                }
            }
        }
        return Math.round(det);
    }
}
