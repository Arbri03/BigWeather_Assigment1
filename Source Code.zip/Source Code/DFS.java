import java.util.*;
/**
 * The class performs depth-first search (DFS) on the graph to identify connected components.
 *  Each connected component is then passed to the component processor.
 */
public class DFS {
    boolean[] visited;
    Graph graph;
/**
 * This is a call to the constructor, which initializes a DFS object with a reference to the graph and a visited array.
 * @param graph the graph for which we want to find connected components
*/
    public DFS(Graph graph) {
        this.graph = graph;
        this.visited = new boolean[graph.n + 1];
    }
/**
 * Runs DFS on all unvisited dynos(nodes) to find and process each connected component.
*/
    public void dfs() {
        Arrays.fill(visited, false);
        for (int v = 1; v <= graph.n; v++) {
            if (!visited[v]) {
                List<Integer> component = new ArrayList<>();
                explore(v, component);
                ComponentProcessor.processComponent(component, graph);
            }
        }
    }
/**
 * Recursive helper function that explores all dynos reachable from v, collecting them into a single component.
 * @param v current dyno(node)
 * @param component the list accumulating the current connected components
*/
    private void explore(int v, List<Integer> component) {
        visited[v] = true;
        component.add(v);
        for (int u : graph.neighbors(v)) {
            if (!visited[u]) {
                explore(u, component);
            }
        }
    }
}
