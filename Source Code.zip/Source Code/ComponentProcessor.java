import java.util.*;
/**
 * This class processes each connected component to determine the optimal coverage strategy(cheapest solution).
 * (all dynos host buckets, one bucket + bonds via spanning tree ).
 * Uses Kirchhoff’s Matrix-Tree Theorem to count valid configurations.
 */
public class ComponentProcessor {
    static int bucketCost;
    static int bondCost;
    static long totalCost = 0;
    static long totalWays = 0;
	
/**
 * Sets the global cost parameters for bucket hosting and bonds cost.
 * @param bucket the cost of hosting a bucket on one dyno
 * @param bond the cost of possible bond between 2 dynos
*/
    public static void setCosts(int bucket, int bond) {
        bucketCost = bucket;
        bondCost = bond;
    }
/**
 * For each component, determines whether it's cheaper to use all buckets
 * or a shared bucket plus bonds and counts the number of
 * distinct valid configurations (using spanning trees + bucket placements).
 * @param component the list of dynos in the connected component
 * @param graph the full graph (used to check connections)
*/
    public static void processComponent(List<Integer> component, Graph graph) {
        int n = component.size();
        long costTree = bucketCost + (n - 1L) * bondCost;
        long costAllBuckets = n * (long) bucketCost;

        if (costTree < costAllBuckets) {
            totalCost += costTree;
            long treeCount = SpanningTreeCounter.countSpanningTrees(component, graph);
            totalWays += (treeCount * n);
        } else if (costTree > costAllBuckets) {
            totalCost += costAllBuckets;
            totalWays = 1;
        } else {
            totalCost += costTree;
            long treeCount = SpanningTreeCounter.countSpanningTrees(component, graph);
            totalWays += (treeCount * n + 1);
        }
    }
}
