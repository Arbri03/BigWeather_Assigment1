import java.io.*;
import java.util.*;
/**
 * This class is the entry point to our application.
 * It reads input graph from a file, initializes the system, and
 * outputs the minimum total cost and number of optimal configurations.
 * It also prints the results.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter path to input file: ");
        String filePath = scanner.nextLine().trim();

        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String[] parts = reader.readLine().trim().split(" ");
        int n = Integer.parseInt(parts[0]);
        int k = Integer.parseInt(parts[1]);
        int bucketCost = Integer.parseInt(parts[2]);
        int bondCost = Integer.parseInt(parts[3]);

        Graph graph = new Graph(n);
        for (int i = 0; i < k; i++) {
            String[] edge = reader.readLine().trim().split(" ");
            int u = Integer.parseInt(edge[0]);
            int v = Integer.parseInt(edge[1]);
            graph.addEdge(u, v);
        }

        ComponentProcessor.setCosts(bucketCost, bondCost);
        DFS dfs = new DFS(graph);
        dfs.dfs();

        System.out.println("Minimum cost to cover all dynos: " + ComponentProcessor.totalCost);
        System.out.println("Distinct optimal configurations found: " + ComponentProcessor.totalWays);
    }
}
